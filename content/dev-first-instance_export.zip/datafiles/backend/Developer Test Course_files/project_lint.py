import random
import pysenpai.core as core

class FakeModule(object):
    pass


msgs = core.TranslationDict()
msgs.set_msg("EOFError", "fi", "Sijoita kaikki syöttekyselyt {{{{{{#!python3 if __name__ == \"__main__\"}}}}}} lohkon alle.")
msgs.set_msg("EOFError", "en", "Place all input prompts under {{{{{{#!python3 if __name__ == \"__main__\"}}}}}}.")

if __name__ == "__main__":
    core.init_test(__file__, 0)
    files, lang = core.parse_command()
    for mname in files:
        if mname.endswith(".py"):
            st_module = FakeModule()
            st_module.__file__ = mname
            core.pylint_test(
                st_module, lang,
                extra_options=["--disable=unused-argument"]
            )
            core.set_result(True, 0)

