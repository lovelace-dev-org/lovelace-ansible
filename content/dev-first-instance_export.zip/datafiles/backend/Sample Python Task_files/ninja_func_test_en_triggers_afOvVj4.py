import math
import random
import re
import string
import pysenpai.core as core
import pysenpai.utils.checker as utils
from pysenpai.callbacks.convenience import rounding_float_result_validator
from pysenpai.exceptions import NoAdditionalInfo, OutputParseError
from pysenpai.checking.testcase import FunctionTestCase, ProgramTestCase, run_test_cases

int_pat = re.compile("[0-9]+")

st_count_func = {
    "fi": "laske_ninjat",
    "en": "count_ninjas",
}

custom_msgs = core.TranslationDict()
custom_msgs.set_msg("error_ref_count_xy", "fi", dict(
    content="Koordinaatteja käytettiin väärässä järjestyksessä.",
    hints=["Tarkista, että käytät y-koordinaattia listan ulompana eli ensimmäisenä indeksinä."]
))
custom_msgs.set_msg("error_ref_count_xy", "en", dict(
    content="Tthe coordinates were used in the wrong order.",
    hints=["Make sure your function uses y as the outer (i.e. first) coordinate."]
))
custom_msgs.set_msg("error_ref_count_bleed", "fi", dict(
    content="Laskenta saattaa vuotaa yli vasemmalta ja/tai ylhäältä.",
    hints=["Negatiiviset indeksit eivät aiheuta poikkeusta, vaan lukevat listaa lopusta alkaen", "Ympäröivät koordinaatit tulee tarkistaa laskentasilmukan sisällä."],
    triggers=["ninja-checking", "ninja-prep", "ninja-negative"]
))
custom_msgs.set_msg("error_ref_count_bleed", "en", dict(
    content="Your counting wraps around from the left and/or top.",
    hints=["Negative list indices do not cause exceptions - they access the list starting from the end", "Surrounding coordinates must be checked inside the counting loop."],
    triggers=["ninja-checking", "ninja-prep", "ninja-negative"]
))
custom_msgs.set_msg("IndexError", "fi", dict(
    content="Koodissa tapahtui IndexError-poikkeus. Lisätietoja:\n{emsg}",
    hints=["Ympäröivät koordinaatit tulee tarkistaa laskentasilmukan sisällä."],
    triggers=["ninja-checking", "ninja-prep"]
))
custom_msgs.set_msg("IndexError", "en", dict(
    content="There was an IndexError exception. Additional information:\n{emsg}",
    hints=["Surrounding coordinates must be checked inside the counting loop."],
    triggers=["ninja-checking", "ninja-prep"]
))
func_msgs = custom_msgs.copy()
func_msgs.set_msg("PrintTestVector", "fi", "Kutsuttiin argumenteilla:\n{args}\n(X on laskentapiste)")
func_msgs.set_msg("PrintTestVector", "en", "Called with arguments:\n{args}\n(X marks the counting spot)")
func_msgs.set_msg("error_ref_global_room", "fi", dict(
    content="Funktio laski ninjat pääohjelmassa määritetystä kentästä.",
    hints=["Varmista, että laskenta suoritetaan siitä kentästä, jonka funktio saa kolmanteen parametriinsa."]
))
func_msgs.set_msg("error_ref_global_room", "en", dict(
    content="Your counting function counted ninjas from the main program room.",
    hints=["Make sure to count ninjas from the room received as the function's third parameter."]
))



class NinjaMainCase(ProgramTestCase):

    def parse(self, output):
        return utils.find_first(int_pat, output, int)


def gen_room_vector():
    v = []
    arg_sets = [
        (2, 2, [
            [" ", " ", " "],
            [" ", "N", "N"],
            [" ", "N", " "],
        ]), 
        (0, 0, [
            [" ", " ", "N"],
            [" ", " ", "N"],
            ["N", "N", " "],
        ])        
    ]
    for i in range(8):
        rw = random.randint(3, 10)
        rh = random.randint(3, 10)
        free = []
        room = []
        for r in range(rh):
            room.append([])
            for c in range(rw):
                content = random.choice("N ")
                room[-1].append(content)
                if content == " ":
                    free.append((c, r))
        
        try:
            x, y = random.choice(free)
        except IndexError:
            x, y = random.randint(0, rw - 1), random.randint(0, rh - 1)
            room[y][x] = " "
            
        arg_sets.append((x, y, room))
        
    for args in arg_sets:
        case = FunctionTestCase(
            args=args,
            ref_result=ref_count_func(*args),
            eref_results=[
                (error_ref_count_bleed(*args), "error_ref_count_bleed"),
                (error_ref_count_xy(*args), "error_ref_count_xy"),
                (error_ref_global_room(*args), "error_ref_global_room"),
            ]
        )
        case.configure_presenters({
            "arg": room_presenter,
        })
        v.append(case)

    return v

def main_vector():
    v = []
    room = [
        ['N', ' ', ' ', ' ', ' '],
        ['N', 'N', 'N', 'N', ' '],
        ['N', ' ', 'N', ' ', ' '],
        ['N', 'N', 'N', ' ', ' '],
        [' ', ' ', ' ', ' ', ' '],
        [' ', ' ', ' ', ' ', ' ']
    ]
    points = [(4, 0), (4, 5), (0, 5)]
    free = []
    for r, row in enumerate(room):
        for c, col in enumerate(row):
            if col == " " and (c, r) not in points:
                free.append((c, r))
    points.extend(random.sample(free, 7))
    for x, y in points:
        case = NinjaMainCase(
            inputs=[x, y],
            ref_result=ref_count_func(x, y, room),
            eref_results=[
                (error_ref_count_bleed(x, y, room), "error_ref_count_bleed"),
                (error_ref_count_xy(x, y, room), "error_ref_count_xy"),
            ]
        )
        v.append(case)
    return v

def ref_count_func(x, y, room):
    n = 0
    for r in room[max(y - 1, 0):min(y + 2, len(room))]:
        for c in r[max(x - 1, 0):min(x + 2, len(r))]:            
            if c == "N":
                n += 1
    return n    
    
def error_ref_count_xy(x, y, room):
    n = 0
    for r in room[max(x - 1, 0):min(x + 2, len(room))]:
        for c in r[max(y - 1, 0):min(y + 2, len(r))]:
            if c == "N":
                n += 1
    return n    
    
def error_ref_count_bleed(x, y, room):
    n = 0
    for i in range(-1, 2):
        for j in range(-1, 2):
            if y + i < len(room) and x + j < len(room[0]):
                if room[y + i][x + j] == "N":
                    n += 1
    return n
    
def error_ref_global_room(x, y, room):
    try:
        room = utils.find_objects(st_module, list, first=True)
        return ref_count_func(x, y, room)
    except:
        return None
    
def room_to_string(room):
    view = ""
    cl = "  "
    for ci in range(len(room[0])):
        cl += str(ci).rjust(2)
    view += cl + "\n"
    for ri, r in enumerate(room):        
        view += str(ri).rjust(2) + " " + " ".join(r) + "\n"
    return view

def room_presenter(val):
    val[2][val[1]][val[0]] = "X"
    return "x: {}, y: {}\n\n{{{{{{\n{}\n}}}}}}".format(val[0], val[1], room_to_string(val[2]))

def copy_room(args):
    x, y, room = args
    new = []
    for r in room:
        new.append([])
        for c in r:
            new[-1].append(c)
    return [x, y, new]

def ninja_grader(cases):
    edge_cases = True
    for case in cases:
        x, y, room = case.args
        w = len(room[0])
        h = len(room)
        if 0 < x < w - 1 and 0 < y < h - 1:
            if not case.correct:
                return 0
        else:
            if not case.correct:
                edge_cases = False
    return 1 + int(edge_cases)

if __name__ == "__main__":
    core.init_test(__file__, 4)
    files, lang = core.parse_command()
    st_mname = files[0]
    st_module = core.load_module(st_mname, lang, inputs=["0", "0"])
    score = 0
    if st_module:
        score += run_test_cases(
            "function", st_count_func[lang], st_module, gen_room_vector, lang,
            custom_msgs=func_msgs,
            grader=ninja_grader
        )
        score += run_test_cases(
            "program", st_module.__name__, st_module, main_vector, lang,
            custom_msgs=custom_msgs,
            hide_output=False
        )
        correct = bool(score)
        score += core.pylint_test(st_module, lang, extra_options=[
            "--const-naming-style=any"
        ])
        core.set_result(correct, score)
