def count_ninjas(x, y, room):
    """
    Counts ninjas (N characters) around the given tile at coordinates x, y of the given room.
    """
    return sum(room[y - j][x - i] == "N" for i in range(-1, 2) for j in range(-1, 2))

testroom = [
    ['N', ' ', ' ', ' ', ' '],
    ['N', 'N', 'N', 'N', ' '],
    ['N', ' ', 'N', ' ', ' '],
    ['N', 'N', 'N', ' ', ' '],
    [' ', ' ', ' ', ' ', ' '],
    [' ', ' ', ' ', ' ', ' ']
]

print(" ", "- " * 5)
for row in testroom:
    print("|", " ".join(row), "|")
print(" ", "- " * 5)
test_x = int(input("X-coordinate: "))
test_y = int(input("Y-coordinate: "))
print(count_ninjas(test_x, test_y, testroom))
