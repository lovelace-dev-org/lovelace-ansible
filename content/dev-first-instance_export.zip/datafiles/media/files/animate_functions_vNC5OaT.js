function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

function addText(name, fadeText, fontType, fontSize, leftPosition, topPosition, fadeStyle, attribute) {
    newElement = document.createElement(`${name}`);
    newText = document.createTextNode(fadeText);
    newElement.classList.add("text", "animated", `${fadeStyle}`, `${attribute}`);
    newElement.setAttribute("style", `font-family: ${fontType}; font-size: 20px; font-size: ${fontSize}px; font-style: normal; left: ${leftPosition}px; top: ${topPosition}px; color: #403f48; text-decoration: none; display: inline-block; position: absolute; z-index:999; font-weight: bold;`);
    newElement.appendChild(newText);
    wrapper.appendChild(newElement);
}

function addLine(name, lineLength, leftPosition, topPosition, fadeStyle, attribute, size, rotation) {
    lineUnder = document.createElement(`${name}`);
    lineUnder.classList.add("lineFade", "animated", `${fadeStyle}`, `${attribute}`);
    lineUnder.setAttribute("style", `border-radius: 10px; display: inline-block; transform: rotate(${rotation}deg); position: absolute; width: ${lineLength}px; height: ${size}px; left: ${leftPosition}px; top: ${topPosition}px; background-color: #403f48`);
    wrapper.appendChild(lineUnder);
}

function addBasicWindow(leftPosition, topPosition, attribute) {
    newWindow = document.createElement("wfi");
    newWindow.classList.add("window", "animated", "fadeIn", `${attribute}`);
    newWindow.setAttribute("style", `left: ${leftPosition}px; top: ${topPosition}px; display: block; width: 195px; height: 220px; background-color: #e3d9ca; border-radius: 10px; border: 8px solid #596c68; position: absolute; cursor: pointer; `);
    wrapper.appendChild(newWindow);
}

function addCustomWindow(name, width, height, leftPosition, topPosition, innerColor, borderColor, attribute) {
    newWindow = document.createElement(`${name}`);
    newWindow.classList.add("window", "animated", "fadeIn", `${attribute}`);
    newWindow.setAttribute("style", `left: ${leftPosition}px; top: ${topPosition}px; display: block; width: ${width}px; height: ${height}px; background-color: ${innerColor}; border-radius: 10px; border: 8px solid ${borderColor}; position: absolute; cursor: pointer; `);
    wrapper.appendChild(newWindow);
}

async function removeElement(name, fadeStyle, attribute, delay) {
    var fadeElement = document.getElementsByTagName(name);
    for (index = fadeElement.length - 1; index >= 0; index--) {
        fadeElement[index].classList.remove("zoomIn");
        fadeElement[index].classList.add(`${fadeStyle}`, `${attribute}`);
        if (delay != undefined) {
            await sleep(delay);
        }
        else {
            await sleep(300);
        }
        wrapper.removeChild(fadeElement[index]);
    }
}