var counter = "0";

loadAnim = function() {
    document.getElementById("start").remove();
    // Setting up the permanent elements
    // Background
    var permaBackground = document.createElement("p");
    permaBackground.classList.add("background", "animated", "fadeIn", "faster");
    permaBackground.setAttribute("style", "display: block; width: 770px; height: 393px; background-color: #95a792; border-radius: 14px; border: 8px solid #403f48; position: absolute; cursor: pointer; left: 0; top: 0;");
    wrapper.appendChild(permaBackground);
    wrapper.addEventListener("click", clickBackground);
    // Top bar
    permaTopBar = document.createElement("p");
    permaTopBar.classList.add("topBar", "animated", "fadeIn", "faster");
    permaTopBar.setAttribute("style", "display: inline-block; width: 724px; height: 49px; background-color: #e3d9ca; border-radius: 10px; border: 8px solid #596c68; position: absolute; left: 23px; top: 31px; absolute; cursor: pointer;");
    wrapper.appendChild(permaTopBar);
    // Click button
    newElement = document.createElement(`Button`);
    newText = document.createTextNode("Click here");
    newElement.classList.add("text", "animated", `fadeIn`, `faster`);
    newElement.setAttribute("style", `outline:none; border-radius: 6px; padding: 2px 5px; border: none; font-family: Arial, Helvetica, sans-serif; font-size: 20px; font-size: 20px; font-style: normal; left: 340px; top: 383px; color: #95a792; text-decoration: none; display: inline-block; position: absolute; z-index:999; font-weight: bold; background-color: #596c68;`);
    newElement.appendChild(newText);
    wrapper.appendChild(newElement);
    // Window number 1
    addBasicWindow(23, 128, "faster")
    // Window number 2
    addBasicWindow(288, 128, "faster")
    // Window number 3
    addBasicWindow(551, 128, "faster")
    addText("names", "Names", "Arial, Helvetica, sans-serif", 23, 303, 140, "fadeIn", "faster");
    addText("values", "Values", "Arial, Helvetica, sans-serif", 23, 568, 140, "fadeIn", "faster");
    addText("x1", "x = 1337", "monospace", 23, 49, 165, "fadeIn", "faster");
    addText("y1", "y = x", "monospace", 23, 49, 221, "fadeIn", "faster");
    addText("x2", "x = 4451", "monospace", 23, 49, 277, "fadeIn", "faster");
    addText("topText", "You can think about variables and values as two boxes", "Arial, Helvetica, sans-serif", 19, 43, 60, "fadeIn", "faster");
}

var lookupTable = {
    "0": async function() {
        wrapper.removeEventListener("click", clickBackground);
        // Fading out the previous texts
        removeElement("topText", "fadeOut", "faster");
        // Fading in new text
        addText("x3", "x", "Arial, Helvetica, sans-serif", 50, 375, 180, "fadeIn", "faster");
        addText("numbers1", "1337", "Arial, Helvetica, sans-serif", 50, 600, 180, "fadeIn", "faster");
        addText("topText", "When variable assignment is executed, a new value is created and referenced", "Arial, Helvetica, sans-serif", 19, 35, 60, "fadeIn", "faster");
        // Zooming in the lines
        addLine("underLine", 113, 46, 191, "zoomIn", "faster", 3);
        addLine("connector1", 190, 410, 210, "zoomIn", "faster", 6)
        // newLine1 = document.createElement("l");
        // newLine1.classList.add("line1", "animated", "zoomIn", "faster");
        // newLine1.setAttribute("style", "border-radius: 10px; display: inline-block; position: absolute; width: 180px; height: 6px; left:410px; top:210px; background-color: #403f48");
        // wrapper.appendChild(newLine1);
        counter = "1";
        await sleep(500);
        wrapper.addEventListener("click", clickBackground);
    },
    "1": async function() {
        wrapper.removeEventListener("click", clickBackground);
        // Fading out the previous texts
        removeElement("topText", "fadeOut", "faster");
        await sleep(400);
        // Fading out the previous lines
        removeElement("underLine", "fadeOut", "faster");
        await sleep(400);
        // Fading in new text
        addText("y2", "y", "Arial, Helvetica, sans-serif", 50, 375, 250, "fadeIn", "faster");
        addText("topText", "When a variable is 'renamed' a new reference to the same value is created", "Arial, Helvetica, sans-serif", 19, 43, 60, "fadeIn", "faster");
        // Zooming in the lines
        addLine("underLine", 74, 46, 250, "zoomIn", "faster", 3);
        addLine("connector2", 190, 410, 245, "zoomIn", "faster", 6, -20)
        // newLine2 = document.createElement("l");
        // newLine2.classList.add("line2", "animated", "zoomIn", "faster");
        // newLine2.setAttribute("style", "transform: rotate(-20deg); border-radius: 10px; display: inline-block; position: absolute; width: 180px; height: 6px; left:410px; top:245px; background-color: #403f48");
        // wrapper.appendChild(newLine2);
        counter = 2;
        await sleep(500);
        wrapper.addEventListener("click", clickBackground);
    },
    "2": async function() {
        wrapper.removeEventListener("click", clickBackground);
        // Fading out the previous texts
        removeElement("topText", "fadeOut", "faster");
        await sleep(400);
        // Fading out the previous lines
        removeElement("underLine", "fadeOut", "faster");
        await sleep(400);
        removeElement("connector1", "zoomOut", "faster")
        // Fading in new text
        addText("numbers2", "4451", "Arial, Helvetica, sans-serif", 50, 600, 260, "fadeIn", "faster");
        addText("topText", "If a new value is assigned to a variable, this creates a new value and changes        the variable's reference target", "Arial, Helvetica, sans-serif", 19, 35, 60, "fadeIn", "faster");
        // Zooming in the lines
        addLine("underLine", 113, 48, 303, "zoomIn", "faster", 3);
        addLine("connector3", 190, 410, 245, "zoomIn", "faster", 6, 20)
        // newLine3 = document.createElement("l");
        // newLine3.classList.add("line2", "animated", "zoomIn", "faster");
        // newLine3.setAttribute("style", "transform: rotate(20deg); border-radius: 10px; display: inline-block; position: absolute; width: 180px; height: 6px; left:410px; top:245px; background-color: #403f48");
        // wrapper.appendChild(newLine3);
        counter = 3;
        await sleep(500);
        wrapper.addEventListener("click", clickBackground);
    },
    "3": async function() {
        wrapper.removeEventListener("click", clickBackground);
        // Fading out the previous texts
        removeElement("topText", "fadeOut", "faster");
        await sleep(400);
        // Fading in new text
        addText("topText", "Click again if you wish to restart the animation.", "Arial, Helvetica, sans-serif", 19, 43, 70, "fadeIn", "faster");
        await sleep(500);
        counter = "final";
        await sleep(500);
        wrapper.addEventListener("click", clickBackground);
    },
    "final": async function() {
        wrapper.removeEventListener("click", clickBackground);
        for (i = 0; i < 8; i++) {
            wrapper.removeChild(wrapper.lastChild);
        }
        lastFade = document.createElement("ff");
        lastFade.classList.add("endFade", "animated", "fadeIn", "faster");
        lastFade.setAttribute("style", `display: inline-block; width: 790px; height: 430px; background-color: #ededed; position: absolute; z-index: 999;`);
        wrapper.appendChild(lastFade);
        await sleep(400);
        lastFade.classList.remove("fadeIn");
        lastFade.classList.add("fadeOut", "faster");
        await sleep(400);
        lastFade.remove();
        addText("topText", "You can think about variables and values as two boxes", "Arial, Helvetica, sans-serif", 19, 43, 60, "fadeIn", "faster");
        counter = 0;
        await sleep(500);
        wrapper.addEventListener("click", clickBackground);

    }
}

async function clickBackground(event) {
    lookupTable[counter]();
}