import base64
import sys
from getpass import getpass
from Crypto.Cipher import AES

def encrypt(data, key, fname):
    cipher = AES.new(key, AES.MODE_EAX)
    ciphertext, tag = cipher.encrypt_and_digest(data)
    with open(fname + ".bin", "wb") as f:
        f.write(cipher.nonce)
        f.write(tag)
        f.write(ciphertext)

if __name__ == "__main__":
    try:
        fname = sys.argv[1]
    except IndexError:
        print("Specify file to encrypt")
    else:
        with open(fname, "rb") as f:
            contents = f.read()

        key = getpass("Input key:").encode("utf-8")
        encrypt(contents, key, fname)


